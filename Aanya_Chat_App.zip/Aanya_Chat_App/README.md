# Aanya Chat App

यह installable web app आपके Render `/chat` backend से जुड़ा है।

1. इन files को HTTPS hosting पर upload करें।
2. `index.html` खोलें।
3. Android Chrome में Menu → Add to Home screen / Install app करें।
4. App में Aanya से सीधे बात करें।

Gemini API key frontend में न डालें; उसे Render Environment Variables में रखें।
